# lecture0

Criptutor is a platform for people who is interested in trading cryptocurrencies.

It contains 4 different pages: index, trading, success stories and contact. All the links work on all the pages and redirect to the correct html page

As you can see, I have used some javascript to give a professional look to the website.

In regards of the requirements for this project:

There is an unordered list enumerating the qualities of our service of trading, one containing our contact number and address in the contact section and different images on every page
The website uses multiple stylesheets with several css properties including classes and ID’s
The website includes 3 different @media queries for 3 different kinds of screen devices: standard, 800 pixels and 600 pixels.
Bootstrap has been used in the success stories page where I have included 2 column tables using Bootstrap’s grid model
Even thought it wasn’t easy I have managed to use a SCSS variable, one SCSS nesting and used one SCSS inheritance

Thank you CS50! 
